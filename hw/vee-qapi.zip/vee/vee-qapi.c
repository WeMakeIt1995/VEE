#include "qemu/osdep.h"
#include "qapi/compat-policy.h"
#include "qapi/visitor.h"
#include "qapi/qmp/qdict.h"
#include "qapi/dealloc-visitor.h"
#include "qapi/error.h"
#include "qemu/timer.h"
#include "qemu/log.h"
#include "qapi-emit-events.h"
#include "monitor/monitor-internal.h"

#include "vee-qapi-visit.h"
#include "vee-qapi-commands.h"
#include "vee-qapi-events.h"
#include "vee-qapi-emit-events.h"

static QEMUTimer g_timer;

static void timer_cb(void *opaque)
{
    qemu_log("%s() \r\n", __FUNCTION__);

    // qapi_event_send_vee_event();

    // timer_mod(&g_timer, qemu_clock_get_us(QEMU_CLOCK_VIRTUAL) + 1e6);
}

void qmp_vee_command(Error **errp)
{
    timer_init_us(&g_timer, QEMU_CLOCK_VIRTUAL, timer_cb, NULL);
    // timer_mod(&g_timer, qemu_clock_get_us(QEMU_CLOCK_VIRTUAL) + 1e6);

    // Object *obj = object_resolve_path_component(NULL, "");
    // if (! obj) {
    //     return;
    // }
    // if (! object_dynamic_cast(obj, TYPE_VEE_PIN_STATE)) {
    //     return;
    // }
}

void vee_qapi_event_emit(vee_QAPIEvent event, QDict *qdict)
{
    Monitor *mon;
    MonitorQMP *qmp_mon;

    QTAILQ_FOREACH(mon, &mon_list, entry) {
        if (!monitor_is_qmp(mon)) {
            continue;
        }

        qmp_mon = container_of(mon, MonitorQMP, common);
        qmp_send_response(qmp_mon, qdict);
    }
}
